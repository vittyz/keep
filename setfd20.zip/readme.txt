SetFileDate ver. 2.0

Installation
============
Run setup.exe and follow instructions. This will install SetFileDate
to a folder of your choice (usually C:\Program Files\SetFileDate).
Uninstall program and all registry entries from Control Panel ->
Add/Remove Programs.

Program Overview
================
SetFileDate is a utility to alter the time and date of one or more selected files
or folders, or entire folder structures. There are several such utilities available, 
but we've found most of them to be too large, too complex or too expensive.
SetFileDate is small, easy to use, and completely free!

How To Use
==========
Select file(s) to modify in the file tab. To select multiple files, use the CTRL-key
and click all the files you wish to modify. You can use the SHIFT-key to easily
select a large number of files. You can also click the Select all button to select
all files in the current folder.

Using the Scan Folder(s) tab, you can easily change the date for a large number
of files. Simply specify a start folder and file filter to change the date of all files found. Enable the Include subfolders button to include files found in 
subdirectories of the specified start folder. The Folder tab will only change file
dates. To modify folder dates, you must instead click on the Select Files tab.

Having specified which files or folders to modify, you must select which dates 
to change. You can change both the Created and Accessed date, in addition 
to the Modified date. Modified is the date that is listed in Windows Explorer.
By default, all three dates are selected. 

Setting all time values to zero (the default setting), will set the timestamp to 
midnight (12 a.m.) .

LEGAL STUFF
===========
This software is distributed as freeware, meaning you can use and distribute
it as you wish, provided that you do not charge anything for doing so. You are
not allowed to distribute this program as part of a commercial product (including
cover disks for magazines, etc.),  without a prior written permisson by No 
Nonsense Software.

DISCLAIMER-THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT WARRANTIES
AS TO PERFORMANCE OF MERCHANTABILITY-OR ANY OTHER WARRANTIES 
WHETHER EXPRESSED OR IMPLIED. NO WARRANTY OF FITNESS FOR A 
PARTICULAR PURPOSE IS OFFERED.

Copyright � 1998-2006 No Nonsense Software. All rights reserved.

http://no-nonsense-software.com/